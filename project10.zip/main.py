def main():
    print("Hello from 11!")


if __name__ == "__main__":
    main()
